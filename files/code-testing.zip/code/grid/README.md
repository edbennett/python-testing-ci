# CI Test

[![Run tests](https://github.com/USERNAME/grid/actions/workflows/pytest.yaml/badge.svg)](https://github.com/USERNAME/grid/actions/workflows/pytest.yaml)


## About
A repository to test continuous integration for the [Introduction to Testing and Continuous Integration in Python](https://edbennett.github.io/python-testing-ci) lesson.
